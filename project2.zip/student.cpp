#include<iostream>
#include<string.h>
#include"student.h"
#include<ctype.h>
#include<stdlib.h>
using namespace std;
Cstudent::Cstudent()//DEFINE CSTUDENT CLASS USING CONSTRUCTOR
{
    strcpy(student_name,"\0");//INTIALIZING VARIABLES TO ZERO
    strcpy(student_email_username,"\0");
    strcpy(student_email_password,"\0");
    strcpy(student_major,"\0");
    student_id=0;
    student_score=0;
    for(int x=0;x<5;x++)
    {
        student_grades[x]=0;
    }
}
Cstudent::~Cstudent()//CSTUDENT CLASS DESTRUCTOR
{
    strcpy(student_name,"\0");
    strcpy(student_email_username,"\0");
    strcpy(student_email_password,"\0");
    strcpy(student_major,"\0");
    student_id=0;
    student_score=0;
    for(int y=0;y<5;y++)
    {
        student_grades[y]=0;
    }
}
char Cstudent::setstudentname()//SETTER FUNCTION
{
    cout<<"Enter the student name : ";
    gets(student_name);//RECIVE STUDENT NAME
    while(strlen(student_name)<1)
    {
                cout<<"Enter a valid name : ";
                gets(student_name);//CHECK VALIDITY OF NAME ENTERED
    }
    for(int i=0;i<strlen(student_name);i++)
    {
        for(int j=0;j<strlen(student_name);j++)
        {
                if(isdigit(student_name[j])!=0||ispunct(student_name[j])!=0)
                {
                cout<<"Enter a valid name : ";
                gets(student_name);//CHECK VALIDITY OF NAME ENTERED
                }
        }
    }
}
char Cstudent::getstudentname()//GETTER FUNCTION
{
    cout<<"student name : "<<student_name<<"\n";//OUTPUTS THE STUDENT NAME
}
int Cstudent::setstudentid()
{
    char number[15];
    cout<<"Enter the student ID : ";
    gets(number);
    while(strlen(number)<1)
    {
                cout<<"Enter a valid student ID : ";
                gets(number);//CHECK VALIDITY OF ID ENTERED
    }
    for(int i=0;i<strlen(number);i++)
    {
        for(int j=0;j<strlen(number);j++)
        {
                if(isalpha(number[j])!=0||ispunct(number[j])!=0||isspace(number[j]))
                {
                cout<<"Enter a valid student ID : ";
                gets(number);//CHECK VALIDITY OF ID ENTERED
                }
        }

    }
    student_id=atoi(number);
}
int Cstudent::getstudentid()
{
    cout<<"student ID : "<<student_id<<"\n";//OUTPUTS STUDENT ID
}
char Cstudent::setemail()
{
    cout<<"Enter the student username : ";
    gets(student_email_username);//RECIVES STUDENT USERNAME
    while(strlen(student_email_username)<1)
    {
        cout<<"Enter a valid student username : ";
        gets(student_email_username);//CHECK VALIDITY OF USERNAME
    }
    for(int i=0;i<strlen(student_email_username);i++)
    {
        for(int j=0;j<strlen(student_email_username);j++)
        {
                if(isdigit(student_email_username[j])!=0||ispunct(student_email_username[j])!=0||isspace(student_email_username[j]))
                {
                if(student_email_username[j]=='.')
                    continue;
                else
                {
                cout<<"Enter a valid student username : ";
                gets(student_email_username);//CHECK VALIDITY OF USERNAME
                }
                }
        }

    }
}
char Cstudent::getemail()//GETTER FUNCTION
{
    cout<<"student email : "<<student_email_username<<"\n";//OUTPUTS STUDENT EMAIL
}
char Cstudent::setstudentpassword()//SETTER FUNCTION
{
    cout<<"Enter the student password : ";
    gets(student_email_password);//REICEVS PASSWORD FROM USER
    while(strlen(student_email_password)<8)
    {
        cout<<"Password length should be more than 8 characters"<<"\n";
        cout<<"Enter a valid password : ";
        gets(student_email_password);//CHECK VALIDITY OF PASSWORD AND LENTGH
    }
}
char Cstudent::getstudentpassword()//GETTER FUNCTION
{
    cout<<"student password : "<<student_email_password<<"\n";//OUTPUTS STUEDNT PASSWORD
}
char Cstudent::setmajor()
{
    char *majors="engineeringbusinesscomputer sciencebiotechnology";
    cout<<"Enter the student major : ";
    gets(student_major);//RECIVES STUDENT MAJOR
    while(strstr(majors,strlwr(student_major))==NULL||strlen(student_major)<1)
    {
        cout<<"Enter a valid major : ";
        gets(student_major);//CHECK VALIDITY OF MAJOR
    }
}
char Cstudent::getmajor()
{
    cout<<"student major : "<<student_major<<"\n";//OUTPUTS STUDENT MAJOR
}
float Cstudent::calculategpa()//A FUCTION TO CALCULATE THE GPA
{
    for(int i=0;i<5;i++)
    {
        student_score+=student_grades[i];//SUMS ALL DATA SAVED IN STUDENT GARDES ARRAY
    }
    student_score=student_score/100;//DEVIES THEM OVER 100 TO GET TOTAL GPA
    return student_score;//OUTPUTS STUDENT GPA
}
float Cstudent::setstudentgrades()//ETTER FUNCTION FOR GRADES
{
    char gradeword[10];
    cout<<"Enter the first grade : ";
    gets(gradeword);//RECIVES STUDENT FIRT GRADE
    while(strlen(gradeword)<1)
    {
        cout<<"Enter a valid first grade : ";
        gets(gradeword);//CHECK VALIDITY OF gradeword
    }
    student_grades[0]=atof(gradeword);
    cout<<"Enter the second grade : ";
    gets(gradeword);//RECIVE SUDENT SECOND GRADE
    while(strlen(gradeword)<1)
    {
        cout<<"Enter a valid second grade : ";
        gets(gradeword);//CHECK VALIDITY OF GRADE
    }
    student_grades[1]=atof(gradeword);
    cout<<"Enter the third grade : ";
    gets(gradeword);//RECIVE SUDENT THIRD GRADE
    while(strlen(gradeword)<1)
    {
        cout<<"Enter a valid third grade : ";
        gets(gradeword);//CHECK VALIDITY OF GRADE
    }
    student_grades[2]=atof(gradeword);
    cout<<"Enter the fourth grade : ";
    gets(gradeword);//RECIVE SUDENT FOURTH GRADE
    while(strlen(gradeword)<1)
    {
        cout<<"Enter a valid fourth grade : ";
        gets(gradeword);//CHECK VALIDITY OF GRADE
    }
    student_grades[3]=atof(gradeword);
    cout<<"Enter the fifth grade : ";
    gets(gradeword);//RECIVE SUDENT FIETH GRADE
    while(strlen(gradeword)<1)
    {
        cout<<"Enter a valid fifth grade : ";
        gets(gradeword);//CHECK VALIDITY OF GRADE
    }
    student_grades[4]=atof(gradeword);//CONVERTS CHAR TO FLOAT
    for(int i=0;i<5;i++)
    {
        while(student_grades[i]<0||student_grades[i]>100)
        {
            cout<<"Enter a valid grade instead of the one entered at "<<i+1<<" :";
            gets(gradeword);
            student_grades[i]=atof(gradeword);
        }
    }
    calculategpa();//CALL FOR CALCULATE GPA FUNCTION IN CSTUDENT CLASS
}
int Cstudent::registerstudent()//SETTER FUNCTION
{
    setstudentid();
    setstudentname();
    setemail();
    setstudentpassword();
    setmajor();
    setstudentgrades();
}
int Cstudent::getstudentinfo()//GETTER FUNCTION
{
    getstudentid();
    getstudentname();
    getemail();
    getstudentpassword();
    getmajor();
    cout<<"GPA : "<<calculategpa()<<"\n";

}
ccourse::ccourse()//DEFINING CCOURSE CLASS
{
    strcpy(course_name,"\0");////INTIALIZING VARIABLES TO ZERO
    strcpy(course_code,"\0");
    course_cost = 0;
}

char ccourse:: setname() // set course name
{
    gets(course_name);//RECIVE COURSE NAME
    while(strlen(course_name)<1)
    {
        cout<<"Enter a valid course name : ";
        gets(course_name);//CHECK VALIDITY OF COURSENAME
    }
    for(int i=0;i<strlen(course_name);i++)
    {
        for(int j=0;j<strlen(course_name);j++)
        {
                if(ispunct(course_name[j])!=0)
                {
                cout<<"Enter a valid course name : ";
                gets(course_name);//CHECK VALIDITY OF COURSENAME
                }
        }
    }
}
char ccourse:: setcode() // set course code
{
    gets(course_code);//RECIVE COURSE CODE
    while(strlen(course_code)<1)
    {
        cout<<"Enter a valid course code : ";
        gets(course_code);//CHECK VALIDITY OF COURSECODE
    }
    for(int i=0;i<strlen(course_code);i++)
    {
        for(int j=0;j<strlen(course_code);j++)
        {
                if(ispunct(course_code[j])!=0)
                {
                if(course_code[j]=='.'||course_code[j]=='_'||course_code[j]=='-')
                    continue;
                else{
                cout<<"Enter a valid course code : ";
                gets(course_code);//CHECK VALIDITY OF COURSECODE
                }
                }
        }
    }
}
float ccourse:: setcost() // set course cost
{
    char number[5];
    gets(number);//RECIVE COURSE COST
    course_cost=atof(number);
    while(course_cost<=0)
    {
        gets(number);
        course_cost=atof(number);
    }
}
char ccourse::getname()//getter function for course name
{
    cout<<course_name<<endl;
}
char ccourse::getcode()//getter function for course code
{
    cout<<course_code<<endl;
}
float ccourse::getcost()//getter function for course cost
{
    cout<<course_cost<<endl;
}

void ccourse::addcourse() //setter function to set all data from user
{
    cout<<"Enter course name : ";
    setname();
    cout<<"Enter course code : ";
    setcode();
    cout<<"Enter course cost : ";
    setcost();
    cout<<"\n";
} // end function AddCourse()

int ccourse::getcourseinfo()//getter function to get all data from user
{
    cout<<"Name of Course : ";
    getname();
    cout<<"Code of Course : ";
    getcode();
    cout<<"Cost of Course : ";
    getcost();
    cout<<"\n";
}// end function getCourse()

ccourse:: ~ccourse()//DESTRUCTOR
{
    strcpy(course_name,"\0");//RETURNS NULL
    strcpy(course_code,"\0");//RETURNS NULL
    course_cost = 0;//REUTRNS ZERO
}

char CPG_Student::setPG_student_job_title()//INTIALIZE UB CLASS FROM CSTUDENT
{
cout<<"Enter the postgraduate job : ";
gets(PG_student_job_title);//RECIVES DATA FROM USER
while(strlen(PG_student_job_title)<1)
{
    cout<<"Enter a valid job name : ";
                gets(PG_student_job_title);//CHECK THE VALIDITY OF INPUT
}
    for(int i=0;i<strlen(PG_student_job_title);i++)
    {
        for(int j=0;j<strlen(PG_student_job_title);j++)
        {
                if(isdigit(PG_student_job_title[j])!=0||ispunct(PG_student_job_title[j])!=0)
                {
                cout<<"Enter a valid job name : ";
                gets(PG_student_job_title);//CHECK THE VALIDITY OF INPUT
                }
        }
    }
}
char CPG_Student::getPG_student_job_title()//THE NEW FUNCTION IN CPG_STUDENT CLASS
{
    cout<<"Job : "<<PG_student_job_title;
}



