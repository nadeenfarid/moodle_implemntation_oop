#include <iostream>
using std::cout;
using std::endl;
#include"student.h" //DEFINE THE HEADER
int main()
{
    printf("%120s\n\n","Welcome to moodle simulator app");
while (1)//START OF THE PROGRAM
{
    char xxx[2];
    int y;
    cout<<"1-Enter number of Students\n2-Enter number of courses\n3-Enter number of graduated students\n4-exit\nEnter your choice : ";
    gets(xxx);//RECIEVES USER CHOICE
    y=atoi(xxx);
    while(y<1 || y>4)//MAKE SURE FROM THE VALIDITY OF THE CHOICE
    {
    cout<<"1-Enter number of Students\n2-Enter number of courses\n3-Enter number of graduated students\n4-exit\nEnter your choice : ";
    gets(xxx);
    y=atoi(xxx);

    }
    cout<<"\n";
    if(y==1)//WILL ACESS TO CALSS CSTUDENT
    {
    int i;
    char rangee[10];
    cout<<"Enter Number of students you want to register on the system : ";
    gets(rangee);//RECIVES THE NUMBER OF STUDENTS
    i=atoi(rangee);
    while(i<=0||i>100)
    {
        cout<<"\nEnter a number greater than zero or less than or equal 100 : ";
        gets(rangee);//MAKE SURE FROM VAIDITY OF THE NUMBER ENTERED
        i=atoi(rangee);
    }
    cout<<"\n";
    Cstudent k[100];
    for (int x=0;x<i;x++)
    {
        k[x].registerstudent();//CALLLING FOR FUNCTION REGISTESTUDENT IN CSTUEDNT CALSS
    }
    for (int y=0;y<i;y++)
    {
        cout<<"\n";
        k[y].getstudentinfo();//CALLING FOR FUNCTION GETSTUDENTINFO IN CSTUDENT CLASS
        cout<<"\n";
    }
    }
    if(y==2)
    {
    cout<<"\nEnter number of Courses you want to register on the system : ";
    char ss[3];//RECIVE THE NUMBER OF COURSES
    gets(ss);
    int n;
    n=atoi(ss);
     while(n<=0||n>100)
    {
        cout<<"\nEnter a number greater than zero or less than or equal 100 : ";
        gets(ss);//MAKE SURE FROM VALIDITY OF THE NUMBER ENTERED
        n=atoi(ss);
    }
    cout<<"\n";
    ccourse t[100];
    for(int i = 0; i < n; i++)
    {
        t[i].addcourse();//CALLING FOR FUNCTION ADDCOURSE IN CCOURSE CLASS
    }
    for(int i = 0; i < n; i++)
    {
        t[i].getcourseinfo();//CALING FOR FUNCTION GETCOURSEINFO IN CCOURSE CLASS
    }
    }
    if(y==3)
    {
    int u;
    char rangeex[10];
    cout<<"Enter Number of graduated students you want to register on the system : ";
    gets(rangeex);//RECIEVE NUMBER OF GRADUATED STUDENTS
    u=atoi(rangeex);
    while(u<=0)
    {
        cout<<"\nEnter a number greater than zero or less than or equal  : ";
        gets(rangeex);
        u=atoi(rangeex);//CONVERTS THE CHAR TO INTEGER
    }
    cout<<"\n";
    CPG_Student ii[100];
    for (int x=0;x<u;x++)
    {
        ii[x].registerstudent();//CALL FOR REGISTERSTUEDNTS IN CSTUDENT CLASS
        ii[x].setPG_student_job_title();//CALL FOR setPG_student_job_title IN CPG_STUDENT
    }
    for (int y=0;y<u;y++)
    {
        cout<<"\n";
        ii[y].getstudentinfo();//CALL FOR GETSTUDENTINFO IN CSTUDET CLASS
        ii[y].getPG_student_job_title();//CALL FOR GetPG_student_job_title IN CPG_STUDENT
        cout<<"\n\n";
    }
    }
    if(y==4)
        return 0;
}
}
#include <iostream>
using std::cout;
using std::endl;
#include"student.h" //DEFINE THE HEADER
int main()
{
    printf("%120s\n\n","Welcome to moodle simulator app");
while (1)//START OF THE PROGRAM
{
    char xxx[2];
    int y;
    cout<<"1-Enter number of Students\n2-Enter number of courses\n3-Enter number of graduated students\n4-exit\nEnter your choice : ";
    gets(xxx);//RECIEVES USER CHOICE
    y=atoi(xxx);
    while(y<1 || y>4)//MAKE SURE FROM THE VALIDITY OF THE CHOICE
    {
    cout<<"1-Enter number of Students\n2-Enter number of courses\n3-Enter number of graduated students\n4-exit\nEnter your choice : ";
    gets(xxx);
    y=atoi(xxx);

    }
    cout<<"\n";
    if(y==1)//WILL ACESS TO CALSS CSTUDENT
    {
    int i;
    char rangee[10];
    cout<<"Enter Number of students you want to register on the system : ";
    gets(rangee);//RECIVES THE NUMBER OF STUDENTS
    i=atoi(rangee);
    while(i<=0||i>100)
    {
        cout<<"\nEnter a number greater than zero or less than or equal 100 : ";
        gets(rangee);//MAKE SURE FROM VAIDITY OF THE NUMBER ENTERED
        i=atoi(rangee);
    }
    cout<<"\n";
    Cstudent k[100];
    for (int x=0;x<i;x++)
    {
        k[x].registerstudent();//CALLLING FOR FUNCTION REGISTESTUDENT IN CSTUEDNT CALSS
    }
    for (int y=0;y<i;y++)
    {
        cout<<"\n";
        k[y].getstudentinfo();//CALLING FOR FUNCTION GETSTUDENTINFO IN CSTUDENT CLASS
        cout<<"\n";
    }
    }
    if(y==2)
    {
    cout<<"\nEnter number of Courses you want to register on the system : ";
    char ss[3];//RECIVE THE NUMBER OF COURSES
    gets(ss);
    int n;
    n=atoi(ss);
     while(n<=0||n>100)
    {
        cout<<"\nEnter a number greater than zero or less than or equal 100 : ";
        gets(ss);//MAKE SURE FROM VALIDITY OF THE NUMBER ENTERED
        n=atoi(ss);
    }
    cout<<"\n";
    ccourse t[100];
    for(int i = 0; i < n; i++)
    {
        t[i].addcourse();//CALLING FOR FUNCTION ADDCOURSE IN CCOURSE CLASS
    }
    for(int i = 0; i < n; i++)
    {
        t[i].getcourseinfo();//CALING FOR FUNCTION GETCOURSEINFO IN CCOURSE CLASS
    }
    }
    if(y==3)
    {
    int u;
    char rangeex[10];
    cout<<"Enter Number of graduated students you want to register on the system : ";
    gets(rangeex);//RECIEVE NUMBER OF GRADUATED STUDENTS
    u=atoi(rangeex);
    while(u<=0)
    {
        cout<<"\nEnter a number greater than zero or less than or equal  : ";
        gets(rangeex);
        u=atoi(rangeex);//CONVERTS THE CHAR TO INTEGER
    }
    cout<<"\n";
    CPG_Student ii[100];
    for (int x=0;x<u;x++)
    {
        ii[x].registerstudent();//CALL FOR REGISTERSTUEDNTS IN CSTUDENT CLASS
        ii[x].setPG_student_job_title();//CALL FOR setPG_student_job_title IN CPG_STUDENT
    }
    for (int y=0;y<u;y++)
    {
        cout<<"\n";
        ii[y].getstudentinfo();//CALL FOR GETSTUDENTINFO IN CSTUDET CLASS
        ii[y].getPG_student_job_title();//CALL FOR GetPG_student_job_title IN CPG_STUDENT
        cout<<"\n\n";
    }
    }
    if(y==4)
        return 0;
}
}
