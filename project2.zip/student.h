#ifndef STUDENT_H
#define STUDENT_H//DEFINE STUDENT.H


class Cstudent
{
public://DEFINING PUBLIC VARIABELS FOR CSTUDENT CLASS
    Cstudent();
    ~Cstudent();
    int registerstudent();
    int getstudentinfo();
    float calculategpa();
    char setstudentpassword();
    char getstudentpassword();
    char setstudentname();
    char getstudentname();
    int setstudentid();
    int getstudentid();
    char setemail();
    char getemail();
    char setmajor();
    char getmajor();
    float setstudentgrades();
    float getstudentgrades();


private://DEFINING PRIVATE VARIABELS FOR CSTUDENT CLASS
    char student_name[50];
    int student_id;
    char namestorage[100][100];
    char IDstorage[100];
    char usernamestorage[100];
    char student_email_username[30];
    char student_major[30];
    float student_grades[5];
    float student_score;
    char student_email_password[30];
};
class ccourse
{
public ://DEFINING PUBLIC VARIABELS FOR CCOURSE CLASS
    ccourse();
    char setname();
    char setcode();
    float setcost();
    char getname();
    char getcode();
    float getcost();
    void addcourse();
    int getcourseinfo();
    ~ccourse();
private ://DEFINING PRIVATE VARIABELS FOR CCOURSE CLASS
    char course_name[30];
    char course_code[10];
    float course_cost;
};
class CPG_Student : public Cstudent{
public:////DEFINING PUBLIC VARIABELS FOR SUBCALSS CLASS
    char setPG_student_job_title();
    char getPG_student_job_title();
protected://DEFINING PROTECTED VARIABELS FOR SUBCLASS CLASS
    char PG_student_job_title[20];
};


#endif // STUDENT_H_ENDED